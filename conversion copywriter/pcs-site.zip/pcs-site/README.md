# Personal Cyber Shield — marketing site (EN)

Eleventy/Nunjucks static site for Personal Cyber Shield. EN-first; positioning: **private-client cyber protection**. Primary CTA: **Book a Private Exposure Assessment — ₪3,500**.

## Build
```
npm install
npm run build      # outputs to _site/
npm start          # local dev server
```
Deploy: static host, publish `_site/` (see `render.yaml`).

## Structure
- `src/en/*.njk` — pages (layout `src/_includes/layouts/vault.njk`)
- `src/_data/i18n/*.json` — strings
- `assets/` — css/js/img
- `.github/workflows/claude.yml` + `CLAUDE.md` — Claude CI (comment `@claude` on an issue/PR; needs `ANTHROPIC_API_KEY` repo secret)

## Copy guardrails
All page copy follows the locked positioning, pricing, and forbidden-vocabulary rules summarized in `CLAUDE.md`. Boundaries ("what we never do") live at `faq.html#boundaries`.

## Before public launch — see TODO
- Fill the two `[CONFIRM]` local-support placeholders in `src/en/leaving-controlling-relationship.njk` (safety page).
- `src/en/why-us.njk` + `founder.njk` are the legacy versions — replace with the finalized Why Us once founder proof is supplied.
- Root `index.html` language redirect defaults to `/he/`; HE/RU are not built — repoint to `/en/` for an EN-only launch.
- Regenerate `sitemap.xml` for EN-only; confirm the language switcher in `vault.njk` doesn't link to unbuilt `/he/`,`/ru/`.
